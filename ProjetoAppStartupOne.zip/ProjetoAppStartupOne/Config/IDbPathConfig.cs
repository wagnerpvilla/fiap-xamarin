﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetoAppStartupOne.Config
{
    public interface IDbPathConfig
    {
        string Path { get; }
    }
}
