﻿using ProjetoAppStartupOne.Model;
using SQLite;
using System;

namespace ProjetoAppStartupOne.Services
{
    public class UsuarioService : BaseService<UsuarioNovo>, IUsuarioNovoService
    {

    }
}
