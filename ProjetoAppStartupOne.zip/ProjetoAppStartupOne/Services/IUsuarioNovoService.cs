﻿using ProjetoAppStartupOne.Model;

namespace ProjetoAppStartupOne.Services
{    
    public interface IUsuarioNovoService : IService<UsuarioNovo>
    {
        
    }
}
