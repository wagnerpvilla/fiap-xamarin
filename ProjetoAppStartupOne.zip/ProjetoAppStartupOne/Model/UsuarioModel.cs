﻿namespace ProjetoAppStartupOne.Model
{
    public class UsuarioModel
    {
        public string Usuario { get; set; }
        public string Senha { get; set; }
    }
}
