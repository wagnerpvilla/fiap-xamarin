﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetoAppStartupOne.Resources
{
    public static class Constants
    {
        public const string EVENT_REFRESH_LIST = "refresh_list";
    }
}
